package com.example.nutricionapp

enum class ProviderType {
    BASIC
}