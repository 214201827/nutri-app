package com.example.nutricionapp

enum class UserType {
    ADMIN,
    NUTRIOLOGO,
    PACIENTE
}